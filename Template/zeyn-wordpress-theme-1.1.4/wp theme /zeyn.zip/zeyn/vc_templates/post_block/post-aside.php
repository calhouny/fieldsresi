<?php
defined('ABSPATH') or die();

global $post;
?>
<div class="post-info">
	<div class="post-content"><?php print $post->content;?></div>
</div>