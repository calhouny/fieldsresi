<?php

/**
 *
 * this part from portfolio layout
 *
 * @package WordPress
 * @subpackage Zeyn
 * @since Zeyn 1.0
 */
global $dt_revealData,$detheme_config;
$terms = get_the_terms(get_the_ID(), 'portcat' );
$cssitem=array();
$term_lists=array();

$featured_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'full',false); 
$modal_effect = (empty($detheme_config['dt-select-modal-effects'])) ? 'md-effect-15' : $detheme_config['dt-select-modal-effects'];

if($featured_image){

	$image=aq_resize($featured_image[0], 400, 200, true, true, true);
}

if ( !empty( $terms ) ) {
      
      foreach ( $terms as $term ) {
        $cssitem[] =sanitize_html_class($term->slug, $term->term_id);
        $term_lists[]="<a href=\"".get_term_link( $term)."\">".$term->name."</a>";
      }

}


$modalcontent='<div id="modal_portfolio_'.get_the_ID().'" class="popup-gallery md-modal '.$modal_effect.'">
	<div class="md-content">'.($featured_image?'<img src="#" rel="'.$featured_image[0].'" class="img-responsive" alt=""/>':"").'		
		<div class="md-description secondary_color_bg">'.get_the_excerpt().'</div>
		<button class="secondary_color_button md-close"><i class="icon-cancel"></i></button>
	</div>
</div>';

array_push($dt_revealData,$modalcontent);
?>
<div id="port-<?php print get_the_ID();?>" <?php post_class('portfolio-item '.@implode(' ',$cssitem),get_the_ID()); ?>>
<div class="post-image-container">
	<?php if ($featured_image) : ?>
	<div class="post-image">
		<img class="img-responsive" src="<?php print ($image)?$image:$featured_image[0]; ?>" alt="<?php the_title();?>" />
	</div>
	<?php endif;?>
	<div class="imgcontrol tertier_color_bg_transparent">
		<div class="imgbuttons">
			<a class="md-trigger btn icon-zoom-in secondary_color_button btn skin-light" data-modal="modal_portfolio_<?php print get_the_ID();?>" onclick="return false;" href="<?php the_permalink(); ?>"></a>
			<a class="btn icon-link-1 secondary_color_button btn skin-light" href="<?php the_permalink(); ?>"></a>
		</div>
	</div>
</div>
	<div class="portfolio-description">
		<div class="portfolio-termlist"><?php print (count($term_lists))?@implode(', ',$term_lists):"";?></div>
		<div class="portfolio-title"><?php the_title();?></div>
		<div class="portfolio-excerpt"><?php the_excerpt();?>
		<a href="<?php echo the_permalink(); ?>" class="read_more" title="<?php echo esc_attr(sprintf(__( 'Detail to %s', 'detheme' ), $post->title_attribute)); ?>"><?php _e('Read more', 'detheme') ?> <i class="icon-right-dir"></i></a>
	</div>
	</div>

</div>